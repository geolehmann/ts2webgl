#include <stdio.h>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>
#include <vector>
#include <string>

#include "HTMLheader.h"
#include <bitset>

struct Vertex
{
	int32_t index;
	float x, y, z;
	Vertex(){}
	Vertex(float _x, float _y, float _z) { x = _x; y = _y; z = _z; }
	Vertex(int32_t i, float _x, float _y, float _z) { index = i; x = _x; y = _y; z = _z; }
};

struct Triangle
{
	int32_t index;
	int32_t v1, v2, v3;
	Triangle(int32_t i, int32_t _x, int32_t _y, int32_t _z) { index = i; v1 = _x; v2 = _y; v3 = _z; }
};

struct Color
{
	int r, g, b;
	int32_t hex;
	Color(){}
	Color(int _a, int _b, int _c){ r = _a; g = _b; b = _c; }
};

enum objtype { SURF, POINTS, PLINE };
enum geotype {am1UK,SyOK,SyUK};

struct GObj
{
	std::vector<Vertex> vertices;
	std::vector<Triangle> triangles;
	int32_t vertexnumber, trianglenumber;
	objtype type;
	geotype geo;
	Color color;
	std::string name;
	std::string description;
};

std::vector<GObj> objects;

inline bool isInteger(const std::string & s)
{
   if(s.empty() || ((!isdigit(s[0])) && (s[0] != '-') && (s[0] != '+'))) return false ;

   char * p ;
   strtol(s.c_str(), &p, 10) ;

   return (*p == 0) ;
}

int main(int argc, char *argv[])
{
	std::cout << "SKUA-GOCAD 2015.5 Surface/Pointset/PLine to HTML-WEBGL Converter\n";
	std::cout << "============================================\n\n";
	std::cout << "(c) Christian Lehmann 11.04.2017\n\n\n";

	std::string filename;

	if (argc < 2)
	{
		std::cout << "Error: no file specified!\n";
		std::cout << "Usage: Drag-and-drop Gocad .ts file onto the program .exe file.\n\n";
		system("PAUSE");
		exit(0);
	}
	filename = argv[1]; // die per drag und drop aufgezogene datei
	//filename = "temp1";


	std::ifstream ifs(filename.c_str(), std::ifstream::in);
	if (!ifs.good())
	{
		std::cout << "Error loading:" << filename << "; File not found!" << "\n";
		system("PAUSE");
		exit(0);
	}

	std::string line, key, rest;
	std::cout << "Started loading GOCAD ASCII file " << filename << "....";
	int linecounter = 0;


	Color lastcolor;
	int debugcounter = 0;
	
	while (!ifs.eof() && std::getline(ifs, line))
	{
		key = "";
		rest = "";
		std::stringstream stringstream(line);
		stringstream >> key >> std::ws >> rest >> std::ws; // erster teil der zeile in key, dann in rest


		if (key == "GOCAD" && rest == "TSurf")
		{
			GObj new_object;
			new_object.type = SURF;
			new_object.vertexnumber = 0;
			new_object.trianglenumber = 0;
			// jetzt bis Ende Surface durchgehen
			while (!ifs.eof() /*&& std::getline(ifs, line)*/)
			{
				std::getline(ifs, line);
				std::stringstream stringstream2(line);
				// n�chste zeilen durchgehen
				key = "";
				rest = "";
				stringstream2 >> key >> std::ws >> rest >> std::ws;
				if (key == "END") break; // Loop der inneren Schleife abbrechen, n�chstes Objekt f�ngt an
				if (key == "name:")
				{
					new_object.name = rest;
					if (rest.find("am1") != std::string::npos && rest.find("UK") != std::string::npos) new_object.geo = am1UK;
					if (rest.find("Sy") != std::string::npos && rest.find("OK") != std::string::npos) new_object.geo = SyOK;
					if (rest.find("Sy") != std::string::npos && rest.find("UK") != std::string::npos) new_object.geo = SyUK;
				}
				if (key == "*solid*color:")
				{
					float r = 0, g = 0, b = 0;
					std::string dummy;
					std::size_t found = rest.find("#");
					if (found != std::string::npos) // Farbe ist bin�r angegeben
					{
						if (rest[0] == '#') { rest.erase(0, 1); }
						std::string str;
						std::stringstream ss;
						int* rgb = new int[3];

						for (int i = 0; i < 3; i++) {
							str = rest.substr(i * 2, 2);
							ss << std::hex << str;
							ss >> rgb[i];
							ss.clear();
						}

						new_object.color = Color(rgb[0], rgb[1], rgb[2]);

					}
					else // Farbe ist als float angegeben
					{
						stringstream2 >> g >> std::ws >> b >> std::ws >> dummy; // dummy enth�lt die 1 am Ende der Farbzeile
						new_object.color = Color(std::stof(rest.c_str())*255.f, g*255.f, b*255.f);
					}
				}
				if (key == "VRTX")
				{
					std::string rw, hw, teufe;
					stringstream2 >> rw >> std::ws >> hw >> std::ws >> teufe >> std::ws;
					new_object.vertices.push_back(Vertex(new_object.vertexnumber, std::stof(rw), std::stof(hw), std::stof(teufe)));
					new_object.vertexnumber = new_object.vertexnumber + 1;
				}

				if (key == "PVRTX")
				{
					std::string rw, hw, teufe, dummy3;
					stringstream2 >> rw >> std::ws >> hw >> std::ws >> teufe >> std::ws >> dummy3 >> std::ws;
					new_object.vertices.push_back(Vertex(new_object.vertexnumber, std::stof(rw), std::stof(hw), std::stof(teufe)));
					new_object.vertexnumber = new_object.vertexnumber + 1;
				}

				if (key == "TRGL")
				{
					int32_t a, b;
					stringstream2 >> a >> std::ws >> b >> std::ws;
					a--; b--;
					new_object.triangles.push_back(Triangle(new_object.trianglenumber, std::stoi(rest) - 1, a, b));
					new_object.trianglenumber = new_object.trianglenumber + 1;
				}
			}
			objects.push_back(new_object);
		}

		if (key == "GOCAD" && rest == "PLine")
		{
			bool end = false;
			while (!ifs.eof())
			{
				GObj new_object;
				new_object.type = PLINE;
				new_object.vertexnumber = 0;
				new_object.trianglenumber = 0;
				new_object.color = Color(255, 0, 0);

				// first process the header
				while (key != std::string("ILINE"))
				{
					std::getline(ifs, line);
					std::stringstream stringstream2(line);
					key = "";
					rest = "";
					stringstream2 >> key >> std::ws >> rest >> std::ws;

					if (key == "name:")
					{
						new_object.name = rest;
						if (rest.find("am1") != std::string::npos && rest.find("UK") != std::string::npos) new_object.geo = am1UK;
						if (rest.find("Sy") != std::string::npos && rest.find("OK") != std::string::npos) new_object.geo = SyOK;
						if (rest.find("Sy") != std::string::npos && rest.find("UK") != std::string::npos) new_object.geo = SyUK;
					}
					if (key == "END") { end = true; break; }
				}
				//key = "test";
				while (!key.empty())
				{
					if (key == "END") { break; } // neu
					std::getline(ifs, line);
					std::stringstream stringstream2(line);
					// n�chste zeilen durchgehen
					key = "";
					rest = "";
					stringstream2 >> key >> std::ws >> rest >> std::ws;
					if (key == "VRTX")
					{
						std::string rw, hw, teufe;
						stringstream2 >> rw >> std::ws >> hw >> std::ws >> teufe >> std::ws;
						float nteufe = std::stof(teufe);  if (nteufe > 0) nteufe = nteufe*-1;
						new_object.vertices.push_back(Vertex(std::stof(rw), std::stof(hw), nteufe));
					}

					if (key == "PVRTX")
					{
						std::string rw, hw, teufe, dummy4;
						stringstream2 >> rw >> std::ws >> hw >> std::ws >> teufe >> std::ws >> dummy4 >> std::ws;
						float nteufe = std::stof(teufe);  if (nteufe > 0) nteufe = nteufe*-1;
						new_object.vertices.push_back(Vertex(std::stof(rw), std::stof(hw), nteufe));
					}
					if (key == "SEG")
					{
						break;
					}
				}




				if (!end) objects.push_back(new_object);
				debugcounter = objects.size();
				if (key == "END") break;
				// segments not needed - order of vertices defines segments
			}
			
		}

		linecounter++;
		if (linecounter == 100000) { std::cout << "Processed 100.000 lines\n"; linecounter = 0; }




	}
	if (objects.size() == 0) { fprintf_s(stderr, "\n\nError: Not a valid GOCAD ASCII file!\n\n"); system("PAUSE"); exit(0); }
	else
	{
		fprintf_s(stderr, "  ...done. \n\n");
		std::cout << "Number of GOCAD objects found:" << objects.size() << "\n";
	}

	// jetzt der zweite teil - alles in html packen
	// =============================================

	std::ofstream html;
	std::string delimiter = ".";
	std::string file_firstname = filename.substr(0, filename.find(delimiter)); // dateiname ohne endung
	html.open(file_firstname + ".html");
	std::string header(reinterpret_cast<const char*>(HTMLheader), sizeof(HTMLheader));
	html << header;



	char* optional = R"=====(
text2.innerHTML = "<img height='42' width='42' src='https://pbs.twimg.com/profile_images/366226936/twitter-logo-kpluss_400x400.jpg'></img>\
<br>\
<b><u>Legende</u></b>\
<br>\
Anhydritmittel (<i>am1</i>)&nbsp;&nbsp;<div style='width:10px;height:5px;border:1px; background-color:green; display: inline-block;'></div><br>\
Fl&ouml;z Ronnenberg (<i>K3RoSy</i>) OK&nbsp;&nbsp;<div style='width:10px;height:5px;border:1px; background-color:yellow; display: inline-block;'></div><br>\
Fl&ouml;z Ronnenberg (<i>K3RoSy</i>) UK&nbsp;&nbsp;<div style='width:10px;height:5px;border:1px; background-color:yellow; display: inline-block;'></div><br>\
<br>";
)=====";
	html << optional;


	char* neu = R"=====(
text2.style.top = 50 + 'px';
text2.style.left = 50 + 'px';
document.body.appendChild(text2);
</script>
<script>
var scene, camera, material, light, ambientLight, renderer;
var meshes = [];
)=====";
	html << neu;


	for (int i = 0; i < objects.size(); i++)
	{
		std::string data_1_surf_start = "var object" + std::to_string(i) + " = [ ";
		html << data_1_surf_start;

		// hier jetzt als string oder char die vertices und triangles...

		std::string data;


		if (objects.at(i).type==SURF) data = std::to_string(objects.at(i).vertexnumber) + ", " + std::to_string(objects.at(i).trianglenumber) + ", "; // erst anzahl vertices, dann anzahl triangles
		if (objects.at(i).type == PLINE) data = ""; // erst anzahl vertices, dann anzahl triangles
		
		
		for (auto v : objects.at(i).vertices) data = data + std::to_string(v.x) + ", " + std::to_string(v.y) + ", " + std::to_string(v.z) + ", ";
		for (auto t : objects.at(i).triangles)data = data + std::to_string(t.v1) + ", " + std::to_string(t.v2) + ", " + std::to_string(t.v3) + ", ";

		data.pop_back();
		data.pop_back(); // letztes Komma + Leerzeichen l�schen


		html << data;

		char* data_1_surf_end = " ];";
		html << data_1_surf_end;
	}

	
	// ======================= now LAST PART - FOOTER =====================================
	char* part2_start = R"=====(
init();
render();
function loadObjects()
{
var i = 0;
)====="; 
	html << part2_start;


	// ============================= part for loading the meshes
	for (int i = 0; i < objects.size();i++)
	{
		char *assign_start;
		if (objects.at(i).type == SURF) { assign_start = R"=====(
			loadTSurf(
			)====="; }

	else {
		assign_start = R"=====(
			loadPLine(
			)=====";
	}





			std::string name = "object" + std::to_string(i);

			std::string assign_end = "); ";

			html << assign_start << name << assign_end;

			std::string color_middle;

			char* color_start = R"=====(
			meshes[i++].material.color = new THREE.Color("rgb()====="; 

			//			meshes[m].material.transparent = true ;
			//			meshes[m].material.opacity = 0.2;


			char* color_end = R"=====()");)====="; 

			// festgelegte Farben f�r am1 und Sylvinit
			color_middle = std::string("159") + std::string(", ") + std::string("255") + std::string(", ") + std::string("123");
			if (objects.at(i).geo == am1UK) color_middle = std::string("0") + std::string(", ") + std::string("255") + std::string(", ") + std::string("123");
			if (objects.at(i).geo == SyUK) color_middle = std::string("255") + std::string(", ") + std::string("255") + std::string(", ") + std::string("0");
			if (objects.at(i).geo == SyOK) color_middle = std::string("255") + std::string(", ") + std::string("124") + std::string(", ") + std::string("80");
			//color_middle = std::to_string(objects.at(i).color.r) + ", " + std::to_string(objects.at(i).color.g) + ", " + std::to_string(objects.at(i).color.b);




			html << color_start << color_middle << color_end;
	}

	// ==============================last part
	char* final_part = R"=====(
	addMeshes();
	};
	</script><canvas style="width: 1847px; height: 933px;" height="933" width="1847"></canvas>
	</body></html>
	)====="; 
	html << final_part;

	html.close();
	fprintf_s(stderr, "\nDone writing to .html file.\n\n");
	system("PAUSE");
	return 0;
}

